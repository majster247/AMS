#include "kernel.h"
#include "vmm.h"
#include "task.h"
#include "io.h"
#include "tar.h"
#include "vfs.h"
#include "shell.h"

// Zapowiedź funkcji z idt.cpp
extern "C" void idt_set_descriptor(uint8_t vector, void* isr, uint8_t flags);

// Zapowiedź symbolu z interrupts.s (asemblera)
extern "C" void isr_keyboard_stub();

extern uint64_t initrd_addr; // Zmienna z multiboot_parser.cpp

extern "C" void second_task() {
    while(1) {
        // Piszemy bezpośrednio do portu szeregowego bez zbędnych funkcji
        outb(0x3F8, 'B'); 
        // Bardzo długa pętla, żebyś zauważył literki
        for(volatile uint64_t i = 0; i < 10000000; i++); 
    }
}

void vga_matrix_effect() {
    uint16_t* vga = (uint16_t*)0xB8000;
    for(int i = 0; i < 80 * 25; i++) {
        uint8_t character = 33 + (i % 94); // Losowe znaki ASCII
        uint8_t color = (i % 15) + 1;
        vga[i] = (uint16_t)character | (uint16_t)(color << 8);
    }
}


void pit_init(uint32_t frequency) {
    uint32_t divisor = 1193180 / frequency;
    outb(0x43, 0x36);             // Command port: Mode 3 (Square wave)
    outb(0x40, (uint8_t)(divisor & 0xFF));        // Low byte
    outb(0x40, (uint8_t)((divisor >> 8) & 0xFF)); // High byte
}



extern "C" void kmain(uint64_t multiboot_info_address) {
    init_serial();
    terminal_initialize();
    
    
    pmm_init(128 * 1024 * 1024, (void*)0x200000);
    parse_multiboot(multiboot_info_address);
    pmm_mark_used(0x0, 0x400000);
    
    idt_init();
    keyboard_init();

    write_serial_string("Włączam przerwania (sti)...\n");
    asm volatile("sti");

    vfs_init();

    //wypisz tekst pliku bible.txt na serial (jest w initrd)
    vfs_node* bible = vfs_find("bible.txt");
    if (bible) {
        uint8_t buffer[128];
        uint32_t offset = 0;
        while (offset < bible->size) {
            uint32_t to_read = (bible->size - offset > 128) ? 128 : (bible->size - offset);
            uint32_t read_bytes = vfs_read(bible, offset, to_read, buffer);
            for (uint32_t i = 0; i < read_bytes; i++) {
                outb(0x3F8, buffer[i]);
            }
            offset += read_bytes;
        }
    } else {
        write_serial_string("Nie znaleziono pliku bible.txt w initrd!\n");
    }


    shell_init();


    while(1) {
        shell_update();
        
        // Mały delay, by QEMU nie brało 100% CPU
        for(volatile int i = 0; i < 50000; i++);
    }
}
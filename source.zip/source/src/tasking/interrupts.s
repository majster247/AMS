[bits 64]
extern schedule
global timer_handler_stub

; interrupts.s
timer_handler_stub:
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15

    mov rdi, rsp    ; Przekaż RSP do schedulera
    call schedule
    mov rsp, rax    ; Zmień RSP na ten zwrócony przez scheduler

    pop r15         ; Popujemy w odwrotnej kolejności!
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax
    iretq           ; Tu dzieje się magia przełączania RIP i RSP
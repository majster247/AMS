#include <common/programs/terminal.h>

using namespace myos::common::programs;

Terminal::Terminal(){}

Terminal::~Terminal(){}
#include <iostream>

using namespace std;

int main(){
    int a = scanf("Give number A:");
    int b = scanf("Give number B:");

    printf(((char)a));
    printf(((char)b));
}
#include <common/programs/korwin.h>

using namespace myos::common::programs;


korwin::KorwinDPKG(){}
korwin::~KorwinDPKG(){}
void korwin::AddProgram(){}
void korwin::DeleteProgram(){}
int korwin::CountPrograms(){
    return korwin::programNumber;
}

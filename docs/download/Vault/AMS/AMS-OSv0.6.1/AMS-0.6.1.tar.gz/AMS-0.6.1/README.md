# AMS-OS


AMS OS is a simple and minimalistic self-writed OS for own research purposes.
This system is writed to better understand low level operations and structure of bootloading and kernel operations

This software is also writed to faster make a distro of it to 16-bit own computer on breadboards
